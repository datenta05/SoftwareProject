package com.example.softfinalproject;

import java.io.IOException;

public interface PaymentController {
    void processPayment() throws IOException;
}
